﻿using System;
using System.Globalization;

namespace Comparing_Strings
{
    class Program
    {
        static void Main(string[] args)
        {
            string first    = "\u00e5";       // å
            string second   = "\u0061\u030a"; // a ̊  
        }
    }
}
