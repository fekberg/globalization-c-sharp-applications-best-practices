﻿using System;

namespace Searching_for_a_String
{
    class Program
    {
        static void Main(string[] args)
        {
            string data = "Can we find this character: a\u030a";

        }
    }
}
