﻿using System;
using System.Globalization;

namespace Exploring_CultureInfo
{
    class Program
    {
        static void Main(string[] args)
        {
            var culture = CultureInfo.CreateSpecificCulture("es");

        }
    }
}
