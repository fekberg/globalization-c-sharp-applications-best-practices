﻿using System;
using System.Globalization;
using System.Text;

namespace Displaying_Numbers_as_Strings
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.Unicode;
        }
    }
}
