﻿using System;
using System.Globalization;
namespace Units_of_Measure
{
    class Program
    {
        static void Main(string[] args)
        {
            CultureInfo culture 
                = CultureInfo.CreateSpecificCulture("sv-SE");

        }
    }
} 
