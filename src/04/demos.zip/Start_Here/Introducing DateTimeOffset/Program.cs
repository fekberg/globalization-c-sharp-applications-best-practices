﻿using System;

namespace Introducing_DateTimeOffset
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
