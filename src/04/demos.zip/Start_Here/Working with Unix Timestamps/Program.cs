﻿using System;

namespace Working_with_Unix_Timestamps
{
    class Program
    {
        static void Main(string[] args)
        {
            long timestamp = 1617282420;
        }
    }
}
 