﻿using System;

namespace Adding_and_Subtracting_Dates
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTimeOffset date
                = new DateTimeOffset(2021, 01, 29, 
                                     23, 59, 00, TimeSpan.Zero);
        }
    }
}
